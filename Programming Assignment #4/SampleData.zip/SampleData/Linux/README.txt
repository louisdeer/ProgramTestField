
The "xor.dat" file contains a pattern set for the exclusive-or problem.
There are four patterns, each with two inputs and one output.  As an
initial test of a backpropagation implementation, this file can be used
as both a training set and a testing set, checking to make sure that
the implementation can properly learn a non-linearly-separable problem.

